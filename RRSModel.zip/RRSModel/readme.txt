
# install packages
install.packages('ssgsea.GBM.classification.tar.gz')
install.packages('RRS.tar.gz')

# load packages
library(ssgsea.GBM.classification)
library(RRS)

# predict RRS score
result = mod.analyze(DNAMethylationProfile,c('res','sen'),'./MOD/')
RRSscore = unlist(result[1,]) - unlist(result[2,])

# NOTICE: DNAMethylationProfile is a DNA methylation profile 
# row: probes, column: samples